package org.douggschwind.games.common;

/**
 * A marker interface for producing Decks of Cards.
 * @author Doug Gschwind
 */
public interface AbstractCard {
}